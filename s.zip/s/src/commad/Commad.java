package commad;

public interface Commad {
    public void execute();
    public void undo();
}
