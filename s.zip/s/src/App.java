import commad.VolumenUpTelevisor;
import commad.turnOffTelevisor;
import commad.turnOnTelevisor;
import device.DiviceButton;
import device.ElectronicaDevice;
import device.Radio;
import device.Television;

public class App {
    public static void main(String[] args) throws Exception {
       ElectronicaDevice televisonOne = new Television("SAMSUNG");

       turnOnTelevisor  onCommad = new turnOnTelevisor(televisonOne);

       DiviceButton onPressd; 
       onPressd = new DiviceButton(onCommad);
       onPressd.press();

       turnOffTelevisor offCommad = new turnOffTelevisor(televisonOne);
       onPressd = new DiviceButton(offCommad);
       onPressd.press();

       VolumenUpTelevisor volumenUp = new VolumenUpTelevisor(televisonOne);
       onPressd = new DiviceButton (volumenUp);
       onPressd.press();
       onPressd.press();
       onPressd.press();

       Television TelevisionTwo = new Television("sony");
       Radio radioOne = new Radio("pionner");

    }
}
