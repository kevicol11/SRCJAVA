package device;

public interface ElectronicaDevice {
    public void on();
    public void off();
    public void volumenUp();
    public void volumenDum();
}
